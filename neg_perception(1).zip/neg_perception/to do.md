# Experigen TO DO list 

Email us with your suggestions, requests, and code contributions. 

* remove reference to missingview.ejs from the settings.js file?

* offline mode (for laptops running Apache)
* offline mode (for iOS, requires phonegap and Apple's iOS Developer Program, $99/year)

* more documentation
* improve sound button support / better encapsulation?
* general encapuslation
* send browser stats to server (with IP locator?)
* replace EJS?
* group-level variables
* add response time measurements 
